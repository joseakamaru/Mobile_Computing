package com.example.jose.josefinal2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.jose.josefinal2.database.TodoTable;
import com.example.jose.josefinal2.contentprovider.MyTodoContentProvider;


/*
 * TodoDetailActivity allows to enter a new todo item
 * or to change an existing
 */
public class TodoDetailActivity extends Activity {
    private Spinner mCategory;
    private EditText mTitleText;
    private EditText mAuthorText;
    private EditText mYearText;
    private EditText mPageText;
    private EditText mIsbnText;

    private Uri todoUri;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.todo_edit);

        mCategory = (Spinner) findViewById(R.id.category);
        mTitleText = (EditText) findViewById(R.id.book_edit_title);
        mAuthorText = (EditText) findViewById(R.id.book_edit_author);

        mYearText = (EditText) findViewById(R.id.book_edit_year);
        mPageText = (EditText) findViewById(R.id.book_edit_page);
        mIsbnText = (EditText) findViewById(R.id.book_edit_isbn);

        Button confirmButton = (Button) findViewById(R.id.todo_edit_button);

        Bundle extras = getIntent().getExtras();

        // Check from the saved Instance
        todoUri = (bundle == null) ? null : (Uri) bundle
                .getParcelable(MyTodoContentProvider.CONTENT_ITEM_TYPE);

        // Or passed from the other activity
        if (extras != null) {
            todoUri = extras
                    .getParcelable(MyTodoContentProvider.CONTENT_ITEM_TYPE);

            fillData(todoUri);
        }

        confirmButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (TextUtils.isEmpty(mTitleText.getText().toString())) {
                    makeToast();
                } else {
                    setResult(RESULT_OK);
                    finish();
                }
            }

        });

    }

    private void fillData(Uri uri) {
        String[] projection = { TodoTable.COLUMN_TITLE,
                TodoTable.COLUMN_AUTHOR, TodoTable.COLUMN_YEAR,
                TodoTable.COLUMN_PAGES, TodoTable.COLUMN_ISBN, TodoTable.COLUMN_CATEGORY};
        Cursor cursor = getContentResolver().query(uri, projection, null, null,
                null);
        if (cursor != null) {
            cursor.moveToFirst();
            String category = cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_CATEGORY));

            for (int i = 0; i < mCategory.getCount(); i++) {

                String s = (String) mCategory.getItemAtPosition(i);
                if (s.equalsIgnoreCase(category)) {
                    mCategory.setSelection(i);
                }
            }

            mTitleText.setText(cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_TITLE)));
            mAuthorText.setText(cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_AUTHOR)));
            mYearText.setText(cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_YEAR)));
            mPageText.setText(cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_PAGES)));
            mIsbnText.setText(cursor.getString(cursor
                    .getColumnIndexOrThrow(TodoTable.COLUMN_ISBN)));


            // Always close the cursor
            cursor.close();
        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        outState.putParcelable(MyTodoContentProvider.CONTENT_ITEM_TYPE, todoUri);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    private void saveState() {
        String category = (String) mCategory.getSelectedItem();
        String title = mTitleText.getText().toString();
        String author = mAuthorText.getText().toString();
        String year = mYearText.getText().toString();
        String pages = mPageText.getText().toString();
        String isbn = mIsbnText.getText().toString();

        // Only save if either title or author or year or pages or isbn
        // is available

        if (author.length() == 0 && title.length() == 0 &&
                year.length()==0 && pages.length()==0 &&
                isbn.length()==0) {
            return;
        }

        ContentValues values = new ContentValues();
        values.put(TodoTable.COLUMN_CATEGORY, category);
        values.put(TodoTable.COLUMN_TITLE, title);
        values.put(TodoTable.COLUMN_AUTHOR, author);
        values.put(TodoTable.COLUMN_YEAR, year);
        values.put(TodoTable.COLUMN_PAGES, pages);
        values.put(TodoTable.COLUMN_ISBN, isbn);

        if (todoUri == null) {
            // New todo
            todoUri = getContentResolver().insert(
                    MyTodoContentProvider.CONTENT_URI, values);
        } else {
            // Update todo
            getContentResolver().update(todoUri, values, null, null);
        }
    }

    private void makeToast() {
        Toast.makeText(TodoDetailActivity.this, "Please maintain a summary",
                Toast.LENGTH_LONG).show();
    }
}