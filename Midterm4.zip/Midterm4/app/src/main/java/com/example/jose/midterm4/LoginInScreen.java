package com.example.jose.midterm4;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Jose on 11/30/17.
 */

public class LoginInScreen extends AppCompatActivity {
    Button btnSignIn, btnSignUp;
    LoginDataBaseAdapter loginDataBaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen_main);

        // create the instance of Databse
        loginDataBaseAdapter = new LoginDataBaseAdapter(this);
        loginDataBaseAdapter = loginDataBaseAdapter.open();

        // Get The Refference Of Buttons
        btnSignIn = (Button) findViewById(R.id.buttonSignIN);
        btnSignUp = (Button) findViewById(R.id.buttonSignUP);

        // Set OnClick Listener on SignUp button
        btnSignUp.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {

                        /// Create Intent for SignUpActivity  abd Start The Activity
                        Intent intentSignUP = new Intent(getApplicationContext(), SignUpActivity.class);
                        startActivity(intentSignUP);
                    }
                });


        // Set On ClickListener on SingIn button
        btnSignIn.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Dialog dialog = createLoginDialog();
                        dialog.show();
                    }
                });


    }


    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();

        // Close The Database
        loginDataBaseAdapter.close();
    }

    public Dialog createLoginDialog() {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View v = inflater.inflate(R.layout.login, null);
        builder.setView(v);
        // get the Refferences of views
        final EditText editTextUserName = (EditText)
                v.findViewById(R.id.editTextUserNameToLogin);
        final EditText editTextPassword = (EditText)
                v.findViewById(R.id.editTextPasswordToLogin);
        builder.setPositiveButton("Login", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(
                    DialogInterface dialog, int id) {
                // get The User name and Password
                String userName = editTextUserName.getText().toString();
                String password = editTextPassword.getText().toString();

                // fetch the Password form database for respective user name
                String storedPassword = loginDataBaseAdapter.getSinlgeEntry(userName);

                // check if the Stored password matches with  Password entered by user
                if (password.equals(storedPassword)) {
                    Toast.makeText(LoginInScreen.this, "Login Successfull", Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                    Intent intentStartActivities = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intentStartActivities);
                } else {
                    Toast.makeText(LoginInScreen.this, "User Name and Does Not Matches", Toast.LENGTH_LONG).show();
                }

            }
        });

        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //...
                    }
                });
        AlertDialog dialog = builder.create();
        return dialog;

    }

}