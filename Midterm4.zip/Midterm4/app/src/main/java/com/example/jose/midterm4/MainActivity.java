package com.example.jose.midterm4;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.FileOutputStream;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements FilesFgt.OnItemSelected,EditorFgt.GoBack {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if (savedInstanceState != null) {  // cleanup existing fragments
            getFragmentManager().executePendingTransactions();
            Fragment fragmentById = getFragmentManager().findFragmentById(R.id.fragment_container);
            if (fragmentById!=null) getFragmentManager().beginTransaction().remove(fragmentById).commit();
        }
        FilesFgt filesFragment = new FilesFgt();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, filesFragment).commit();

    }


    @Override
    public void updateEditorFgt(String listToPrint) {

        EditorFgt newFragment = new EditorFgt();
        Bundle args = new Bundle();
        args.putString(EditorFgt.EXTRA,listToPrint);
        // args.putString(DetailFgt.EXTRA, info);
        newFragment.setArguments(args);
        android.support.v4.app.FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, newFragment);
        transaction.addToBackStack(null);
        transaction.commit();

    }
    @Override
    public void createNewFile(String fileName) {
        String filename = fileName;
        String string = "";
        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(string.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void goBack(){

        getFragmentManager().executePendingTransactions();
        Fragment fragmentById = getFragmentManager().findFragmentById(R.id.fragment_container);
        if (fragmentById!=null) getFragmentManager().beginTransaction().remove(fragmentById).commit();

        FilesFgt filesFragment = new FilesFgt();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, filesFragment).commit();
    }
    @Override
    public void done(){
        finish();
    }

    @Override
    public void startService(ArrayList<String> strInputMsg){
        Intent intent = new Intent(getBaseContext(), MyService.class);
        intent.putStringArrayListExtra(EditorFgt.MESSAGE, strInputMsg);
        startService(intent);
    }
}
