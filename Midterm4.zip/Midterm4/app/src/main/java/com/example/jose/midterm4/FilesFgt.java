package com.example.jose.midterm4;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link FilesFgt.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link FilesFgt#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FilesFgt extends Fragment {

    Button create;
    ListView simpleList;
    private OnItemSelected listener;
    List<String> filesList = new ArrayList<String>();
    String main_folder;
    String newName;

    public FilesFgt() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.files_fgt, container, false);
        create = (Button) view.findViewById(R.id.create);
        simpleList = (ListView) view.findViewById(R.id.simpleListView1);
        main_folder = String.valueOf(getContext().getFilesDir());


        updatelist();
        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                String str = (String) simpleList.getItemAtPosition(position);
                // Toast.makeText(getActivity(), str, Toast.LENGTH_SHORT).show();
                Dialog dialog = createLoginDialogOpen(str);
                dialog.show();
            }
        });
        create.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Dialog dialog = createLoginDialogCreate();
                dialog.show();
            }
        });
        registerForContextMenu(simpleList);
        return view;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnItemSelected) {
            listener = (OnItemSelected) context;
        } else {
            throw new ClassCastException(context.toString() +
                    " Interface OnItemSelectedListener not implemented");
        }
    }

    public interface OnItemSelected {
        void updateEditorFgt(String name);
        void createNewFile(String name);
    }

    public void updatelist(){
        List<String> tempList = new ArrayList<String>();
        File folder = new File(main_folder);
        File[] listOfFiles = folder.listFiles();
        for (File file1 : listOfFiles) {
            if (file1.isFile()) {
                tempList.add(file1.getName());
            }
        }
        filesList=tempList;
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, filesList);
        simpleList.setAdapter(myAdapter);
    }

    public Dialog createLoginDialogOpen(final String name) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_open, null);
        builder.setView(v);
        final TextView username = (TextView) v.findViewById(R.id.fileName);
        String print ="Opening File: " + name;
        username.setText(print);

        builder.setPositiveButton("Open",
                new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int id) {
                        openFile(name);
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });

        AlertDialog dialog = builder.create();
        return dialog;
    }

    public Dialog createLoginDialogRename(final String file_name) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_rename, null);
        builder.setView(v);
        final EditText username = (EditText) v.findViewById(R.id.username);

        builder.setPositiveButton("Rename",
                new DialogInterface.OnClickListener() {
                    @Override public void onClick(
                            DialogInterface dialog, int id) {
                        newName = username.getText().toString();
                        // Toast.makeText(getActivity(), "Selection: "+ newName+ " / "+ file_name, Toast.LENGTH_LONG).show();
                        File new_file = new File(getActivity().getFilesDir(), file_name);
                        File to_file = new File(getActivity().getFilesDir(), newName);
                        new_file.renameTo(to_file);
                        updatelist();
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });
        AlertDialog dialog = builder.create();
        return dialog;
    }
    public Dialog createLoginDialogCreate() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_create, null);
        builder.setView(v);
        final EditText fileName = (EditText) v.findViewById(R.id.fileName);

        builder.setPositiveButton("Create",
                new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int id) {
                        newName = fileName.getText().toString();
                        String filename = newName;
                        listener.createNewFile(newName);
                        updatelist();
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });
        AlertDialog dialog = builder.create();
        return dialog;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId() == R.id.simpleListView1) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
            String print = "File: " + filesList.get(info.position);
            menu.setHeaderTitle(print);
            String[] menuItems = getResources().getStringArray(R.array.menu);
            for (int i = 0; i<menuItems.length; i++) {
                menu.add(Menu.NONE, i, i, menuItems[i]);
            }
        }
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int menuItemIndex = item.getItemId();
        String[] menuItems = getResources().getStringArray(R.array.menu);
        String menuItemName = menuItems[menuItemIndex];
        String listItemName = filesList.get(info.position);

        if(menuItemName.equals("Open")) {
            openFile(listItemName);
        }else if(menuItemName.equals("Delete")) {
            File new_file = new File(getActivity().getFilesDir(), listItemName);
            new_file.delete();
            updatelist();
        }else if(menuItemName.equals("Rename")) {
            Dialog dialog1 = createLoginDialogRename(listItemName);
            dialog1.show();
        }
        // Toast.makeText(MainActivity.this, "Selection: "+ menuItemName+ " / "+ listItemName, Toast.LENGTH_LONG).show();
        return true;
    }

    public void openFile(String name){
        listener.updateEditorFgt(name);
    }

}
