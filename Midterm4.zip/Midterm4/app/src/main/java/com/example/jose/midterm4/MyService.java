package com.example.jose.midterm4;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.util.ArrayList;

public class MyService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onDestroy() {

        super.onDestroy();
        Toast.makeText(MyService.this, "Stopping Music Service", Toast.LENGTH_LONG).show();
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId){

        ArrayList<String> msg = intent.getStringArrayListExtra(EditorFgt.MESSAGE);

        String fileName = msg.get(0);
        String data = msg.get(1);
        try {
            FileOutputStream out = this.openFileOutput(fileName, MODE_PRIVATE);
            out.write(data.getBytes());
            out.close();

            Toast.makeText(this, "File saved!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error:", Toast.LENGTH_SHORT).show();
        }

        // Toast.makeText(MyService.this, "Starting Music Service/" + msg.get(1), Toast.LENGTH_LONG).show();
        return START_STICKY;
    }

}

