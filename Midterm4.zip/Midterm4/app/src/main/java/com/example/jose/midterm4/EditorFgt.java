package com.example.jose.midterm4;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link EditorFgt.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link EditorFgt#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EditorFgt extends Fragment {

    private EditorFgt.GoBack listener;
    TextView textView;
    private EditText textET;
    public static final String EXTRA ="extra";
    String fileName;
    public final static String MESSAGE =  "ClassDescription";
    ArrayList<String> strInputMsg = new ArrayList<String>();
    String selectedText = "";

    public EditorFgt() {
        // Required empty public constructor
    }

    public interface GoBack {
        void goBack();
        void done();
        void startService(ArrayList<String> strInputMsg);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof FilesFgt.OnItemSelected) {
            listener = (EditorFgt.GoBack) context;
        } else {
            throw new ClassCastException(context.toString() +
                    " Interface OnItemSelectedListener not implemented");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.editor_fgt, container, false);
        textView = (TextView) view.findViewById(R.id.textView);
        textET = (EditText) view.findViewById(R.id.textDisplayET);
        setHasOptionsMenu(true);
        registerForContextMenu(textET);

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            fileName = bundle.getString(EXTRA);
            openText(fileName);
        }
    }

    public void openText(String name) {
        fileName=name;
        try {
            FileInputStream in = getContext().openFileInput(fileName);
            BufferedReader br= new BufferedReader(new InputStreamReader(in));
            StringBuilder sb= new StringBuilder();
            String s= null;
            while((s = br.readLine()) != null)  {
                sb.append(s).append("\n");
            }
            textET.setText(sb.toString());
        } catch (Exception e) {
            Toast.makeText(getActivity(), "Error:", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // TODO Add your menu entries here
        inflater.inflate(R.menu.main_menu, menu);

        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.option1:
                strInputMsg.add(fileName);
                strInputMsg.add(textET.getText().toString());
                listener.startService(strInputMsg);
                return true;
            case R.id.option2:
                strInputMsg.add(fileName);
                strInputMsg.add(textET.getText().toString());
                listener.startService(strInputMsg);
                listener.goBack();
                return true;
            case R.id.option3:
                listener.goBack();
                return true;
            case R.id.option4:
                listener.done();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId() == R.id.textDisplayET) {
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
            String[] menuItems = getResources().getStringArray(R.array.menu2);
            for (int i = 0; i<menuItems.length; i++) {
                menu.add(Menu.NONE, i, i, menuItems[i]);
            }
        }
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int menuItemIndex = item.getItemId();
        String[] menuItems = getResources().getStringArray(R.array.menu2);
        String menuItemName = menuItems[menuItemIndex];

        if(menuItemName.equals("Cut")) {
            int startSelection = textET.getSelectionStart();
            int endSelection = textET.getSelectionEnd();
            selectedText = textET.getText().toString().substring(startSelection, endSelection);
            String before = textET.getText().toString().substring(0, startSelection);
            String after = textET.getText().toString().substring(endSelection, textET.getText().toString().length());
            textET.setText(before+after);
            // Toast.makeText(getActivity(), "Selection: Cut =" +before, Toast.LENGTH_LONG).show();
        }else if(menuItemName.equals("Copy")) {
            int startSelection = textET.getSelectionStart();
            int endSelection = textET.getSelectionEnd();
            selectedText = textET.getText().toString().substring(startSelection, endSelection);
            // Toast.makeText(getActivity(), "Selection: Copy ="+ selectedText, Toast.LENGTH_LONG).show();
        }else if(menuItemName.equals("Paste")) {
            int startSelection = textET.getSelectionStart();
            int endSelection = textET.getSelectionEnd();

            String before = textET.getText().toString().substring(0, startSelection);
            String after = textET.getText().toString().substring(endSelection, textET.getText().toString().length());
            textET.setText(before+selectedText+after);

            Toast.makeText(getActivity(), "Selection: Paste", Toast.LENGTH_LONG).show();
            selectedText="";
        }
        // Toast.makeText(MainActivity.this, "Selection: "+ menuItemName+ " / "+ listItemName, Toast.LENGTH_LONG).show();
        return true;
    }



}
