package com.example.jose.josefinal6clientapp;

import android.app.Fragment;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DetailFgt extends Fragment {

    public static final String EXTRA ="extra";
    EditText titleET, authorET, yearET, pagesET, isbnET;
    String title;
    Book bookByTitle;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detail_fgt, container, false);

        titleET = (EditText)view.findViewById(R.id.editTitle);
        authorET = (EditText)view.findViewById(R.id.editAuthor);
        yearET = (EditText)view.findViewById(R.id.editYear);
        pagesET = (EditText)view.findViewById(R.id.editPages);
        isbnET = (EditText)view.findViewById(R.id.editIsbn);

        //VERY IMPORTANT: The call from the buttons from the layout to the activity DOES NOT WORK!!!
        //You must do this method or the app will crash without catching error

        Button updateButton = (Button) view.findViewById(R.id.btnUpdate);
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {updateBook();}});

        Button clearButton = (Button) view.findViewById(R.id.btnClear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {clearEditTexts();}});

        Button cancelButton = (Button) view.findViewById(R.id.btnCancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {cancelUpdate();}});

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            title = bundle.getString(EXTRA);
            bookByTitle = getBookByTitle(title);
            titleET.setText(bookByTitle.getBookTitle());
            authorET.setText(bookByTitle.getBookAuthor());
            yearET.setText(bookByTitle.getBookYear());
            pagesET.setText(bookByTitle.getBookPages());
            isbnET.setText(bookByTitle.getBookIsbn());
        }
    }

    //CALL METHOD ON PROVIDER "query" WHICH RETURNS OBJ BOOK.
    //KEY IS THAT WHEN NOT IN PROVIDER CLASS YOU MUST HAVE "getActivity()." before calling getContentResolver
    public Book getBookByTitle(String title){
        String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
        Uri books = Uri.parse(URL);//create uri for query
        Book bookByTitle = new Book();//create Book object to store results from query by title
        Cursor c = getActivity().getContentResolver().query(//create cursor c to store query results, must have 5 pararmeters listed in BookProvider
                books,//uir
                // String[] projection = parameters in database I want to query from, here it is all of them
                new String[] {ProviderContract.ID, ProviderContract.TITLE, ProviderContract.AUTHOR, ProviderContract.YEAR, ProviderContract.PAGES, ProviderContract.ISBN},
                //String selection = row I want to search
                ProviderContract.TITLE + "=?",
                //String[] selectionArgs = value of item to search
                new String[] {title},
                "title");// String sortOrder = really do not need sort order "title" since only one record should be returned
        if (c.moveToFirst()){
            do {
                bookByTitle.setId(Integer.parseInt(c.getString(0)));
                bookByTitle.setBookTitle(c.getString(1));
                bookByTitle.setBookAuthor(c.getString(2));
                bookByTitle.setBookYear(c.getString(3));
                bookByTitle.setBookPages(c.getString(4));
                bookByTitle.setBookIsbn(c.getString(5));
            } while (c.moveToNext());
        }
        String emptyTitleCheck;
        emptyTitleCheck = bookByTitle.getBookTitle();
        if (TextUtils.isEmpty(emptyTitleCheck)) {
            Toast.makeText(getContext(), "No Titles Match Search", Toast.LENGTH_SHORT).show();
        }
        return bookByTitle;
    }

    // Updates book information when called.
    public void updateBook () {
        try{
            String updateTitle = titleET.getText().toString();
            String updateAuthor = authorET.getText().toString();
            String updateYear = yearET.getText().toString();
            String updatePages = pagesET.getText().toString();
            String updateIsbn = isbnET.getText().toString();

            //Checks to see if any of the fields are empty, if yes display toast
            if (TextUtils.isEmpty(updateTitle) || TextUtils.isEmpty(updateAuthor) || TextUtils.isEmpty(updateYear) ||
                    TextUtils.isEmpty(updatePages) || TextUtils.isEmpty(updateIsbn)) {
                Toast.makeText(getContext(), "All Fields Must Be Filled", Toast.LENGTH_LONG).show();

            } else {

                //Creates content values which are passed to the provider to actually update the content
                ContentValues values = new ContentValues();
                values.put(ProviderContract.TITLE, updateTitle);
                values.put(ProviderContract.AUTHOR, updateAuthor);
                values.put(ProviderContract.YEAR, updateYear);
                values.put(ProviderContract.PAGES, updatePages);
                values.put(ProviderContract.ISBN, updateIsbn);

                //block to get original ID value for record to update using the title variable sent by the ListFgt
                int originalID = bookByTitle.getId();//HAD TO MAKE bookByTitle public IOT use here. It is the returned Book object from the getBookByTitle method at oncreate
                String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
                Uri books = Uri.parse(URL);
                int filesUpdated = getActivity().getContentResolver().update(// (uri, String selection, String[] selectionArgs)
                        books,//uri
                        values,//ContentValue with data for each field from the edit texts, did not need ID included since updating by it
                        ProviderContract.ID + "=?",//selection is the row I want to search from to update
                        new String[] {Integer.toString(originalID)}//ID of book I want to update, here we get the original ID # before the edit
                );

            }
            Toast.makeText(getContext(), "Book Information Updated", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            String str = e.getMessage();
            Toast.makeText(getContext(), str, Toast.LENGTH_LONG).show();
        }
    }


    //Clears the edit text fields
    public void clearEditTexts (){
        String str = "";
        titleET.setText(str);
        authorET.setText(str);
        yearET.setText(str);
        pagesET.setText(str);
        isbnET.setText(str);
        Toast.makeText(getContext(), "Fields Are Cleared", Toast.LENGTH_SHORT).show();
    }

    //Cancel edits to book, and return to list view
    public void cancelUpdate (){
        //use ClearEditTexts function because onBackPressed will cause the app to shut down
        //this is more vital when using two plane mode
        if (getResources().getBoolean(R.bool.twoPaneMode)){
            clearEditTexts();
        } else {
            //Return to ListFgt if in single plane mode
            getActivity().onBackPressed();
        }
    }
}
