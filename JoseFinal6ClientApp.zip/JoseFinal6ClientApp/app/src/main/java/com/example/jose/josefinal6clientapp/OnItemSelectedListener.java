package com.example.jose.josefinal6clientapp;

/**
 * Created by Jose on 12/12/17.
 */

public interface OnItemSelectedListener {

    public void onBookSelected(String title);

}
