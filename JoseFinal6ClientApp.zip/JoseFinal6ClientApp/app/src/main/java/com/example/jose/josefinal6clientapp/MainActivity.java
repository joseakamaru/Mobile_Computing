package com.example.jose.josefinal6clientapp;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity implements OnItemSelectedListener{

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if (getResources().getBoolean(R.bool.twoPaneMode)) {
            //It is important to clean the fragment container to update properly
            if (savedInstanceState != null) {
                getFragmentManager().executePendingTransactions();
                Fragment fragmentById = getFragmentManager().
                        findFragmentById(R.id.fragment_container);
                if (fragmentById!=null) getFragmentManager().beginTransaction().
                        remove(fragmentById).commit();
            }//End of cleaning of container


            FragmentManager fm = getFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.frame1, new ListFgt());
            ft.add(R.id.frame2, new DetailFgt());
            ft.commit();
        }

        else {
            if (savedInstanceState != null) {
                //It is important to clean the fragment in frame1 or it will not update properly
                getFragmentManager().executePendingTransactions();
                Fragment fragmentById = getFragmentManager().
                        findFragmentById(R.id.frame1);
                if (fragmentById!=null) getFragmentManager().beginTransaction().
                        remove(fragmentById).commit();
            }//end of clean up

            ListFgt listFragment = new ListFgt();
            getFragmentManager().beginTransaction().
                    replace(R.id.fragment_container, listFragment).commit();
        }
    }

    @Override
    public void onBookSelected(String title) {

        if (getResources().getBoolean(R.bool.twoPaneMode)) {

            DetailFgt newFragment = new DetailFgt();
            Bundle args = new Bundle();
            args.putString(DetailFgt.EXTRA, title);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.frame2, newFragment);
            transaction.commit();
        } else {
            DetailFgt newFragment = new DetailFgt();
            Bundle args = new Bundle();
            args.putString(DetailFgt.EXTRA, title);
            newFragment.setArguments(args);
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.fragment_container, newFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }




}
