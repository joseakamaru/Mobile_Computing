package com.example.jose.josefinal6clientapp;

/**
 * Created by Jose on 12/12/17.
 */

public class Book {
    int id;
    String bookTitle;
    String bookAuthor;
    String bookYear;
    String bookPages;
    String bookIsbn;
    public Book(){  }
    public Book(int id, String title, String author, String year, String pages, String isbn){
        this.id = id;
        this.bookTitle = title;
        this.bookAuthor = author;
        this.bookYear = year;
        this.bookPages = pages;
        this.bookIsbn = isbn;
    }
    public int getId() { return id; }
    public void setId(int id){this.id = id;}

    public String getBookTitle() { return bookTitle;}
    public void setBookTitle(String title)
    { bookTitle = title; }

    public String getBookAuthor() { return bookAuthor; }
    public void setBookAuthor(String author)
    { bookAuthor = author; }

    public String getBookYear() { return bookYear; }
    public void setBookYear(String year)
    { bookYear = year; }

    public String getBookPages() { return bookPages; }
    public void setBookPages(String pages)
    { bookPages = pages; }

    public String getBookIsbn() { return bookIsbn; }
    public void setBookIsbn(String isbn)
    { bookIsbn = isbn; }
}
