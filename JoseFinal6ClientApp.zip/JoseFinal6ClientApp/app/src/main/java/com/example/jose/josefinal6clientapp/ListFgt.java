package com.example.jose.josefinal6clientapp;

import android.app.Dialog;
import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;


public class ListFgt extends Fragment {

    ListView listView;
    ArrayList<String> bookArrayList;
    private OnItemSelectedListener listener;
    FloatingActionButton myFAB;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fgt, container, false);

        setHasOptionsMenu(true);//for option menu

        //Listview is used here for all commands to use
        listView=(ListView)view.findViewById(R.id.listView);


        showAllBooks();//IOT show all books at the app start
        myFAB = (FloatingActionButton) view.findViewById(R.id.myFAB);

        myFAB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //doMyThing();

                Dialog dialogFAB = addBookDialog();
                dialogFAB.show();
            }
        });
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnItemSelectedListener) {
            listener = (OnItemSelectedListener) context;
        } else {
            throw new ClassCastException(context.toString() +
                    " Interface OnItemSelectedListener not implemented");
        }
    }

    //CALL METHOD TO SHOW ALL FROM PROVIDER CLASS "query" WITH NO ARGUMENTS
    //KEY IS THAT WHEN NOT IN PROVIDER CLASS YOU MUST HAVE "getActivity()." before calling getContentResolver
    public ArrayList<String> showAllBooks () {
        String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
        Uri books = Uri.parse(URL);

        //Have to add "getActivity()" in front of "getContentResolver" to make this work in fragment
        Cursor c = getActivity().getContentResolver().query(
                books, null, null, null, "title");
        String result = "Book List: ";

        //create variables for list view display
        //initialize array for each book
        ArrayList<String> bookArrayList = new ArrayList<>();

        //create empty string to build rows
        String str = "";
        if (!c.moveToFirst()) {
            Toast.makeText(getContext(), result + "No Content In List!",
                    Toast.LENGTH_LONG).show();
        } else {
            do {
                //Use to validate results against toast
                result = result + "\n" +
                        c.getString(c.getColumnIndex(ProviderContract.TITLE)) +
                        c.getString(c.getColumnIndex(ProviderContract.AUTHOR)) +
                        c.getString(c.getColumnIndex(ProviderContract.YEAR)) +
                        c.getString(c.getColumnIndex(ProviderContract.PAGES)) +
                        c.getString(c.getColumnIndex(ProviderContract.ISBN));

                //Only used the title from the cursor to fill the listview
                String row =
                        c.getString(c.getColumnIndex(ProviderContract.TITLE));
                str += row;//make str = itself plus the value of row
                bookArrayList.add(str);//add the record to the array
                str = "";//zero out for next iteration
            } while (c.moveToNext());
        }

        //toast and then set list view to show results of all books and set on clickliester
        //Toast.makeText(getContext(), result, Toast.LENGTH_LONG).show();//toast of all records
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(
                getContext(), android.R.layout.simple_list_item_1, bookArrayList);
        listView.setAdapter(myAdapter);

        //the onclicklistener is set for the listview and will pass the value (item click) to the
        //detail fragment by using the listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String title = (String) listView.getItemAtPosition(position);
                //Toast.makeText(getContext(), title, Toast.LENGTH_SHORT).show();//toast of book title clicked
                //call method to get book by title with try/catch error to be displayed in titleET
                listener.onBookSelected(title);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int pos, long id) {

                final String longClickTitle = (String) listView.getItemAtPosition(pos);

                registerForContextMenu(listView);


                AlertDialog.Builder builderDelete =
                        new AlertDialog.Builder(getContext());
                LayoutInflater inflaterDelete = getActivity().getLayoutInflater();//had to make getActviity()
                View vDelete = inflaterDelete.inflate(R.layout.long_click_delete, null);
                builderDelete.setView(vDelete);

                TextView textView = (TextView) vDelete.findViewById(R.id.longClickText);
                textView.setText("Want To Delete " +longClickTitle+" ?");
                        builderDelete.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                deleteBookByTitle(longClickTitle);
                                showAllBooks();
                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                            }
                        })
                        .show();

                return true;
            }

        });

        return bookArrayList;//not really needed since we moved all the actions into the method

    }




    public void deleteContact(int id){

// your code what to do for the clicked item
    }





    //Get book by the author
    public ArrayList<String> showBooksByAuthor (String author) {
        String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
        Uri books = Uri.parse(URL);

        //Create cursor c to store query results which must have 5 pararmeters listed in BookContentProvider
        Cursor c = getActivity().getContentResolver().query(
                books,//uir

                // String[] projection = parameters in database I want to query from, here it is all of them
                new String[] {ProviderContract.ID, ProviderContract.TITLE, ProviderContract.AUTHOR,
                        ProviderContract.YEAR, ProviderContract.PAGES, ProviderContract.ISBN},

                //String selection = row I want to search
                ProviderContract.AUTHOR + "=?",

                //String[] selectionArgs = value of item to search
                new String[] {author},
                // String sortOrder = really do not need sort order "title" since only one record should be returned
                "title");

        String result = "Results:";

        //create variables for list view display
        //intialize array for each book
        ArrayList<String> bookArrayList = new ArrayList<>();
        //create empty string to build rows
        String str = "";
        if (!c.moveToFirst()) {
            Toast.makeText(getContext(), result + "No content!",
                    Toast.LENGTH_LONG).show();
        } else {
            do {
                result = result + "\n" +
                        c.getString(c.getColumnIndex(ProviderContract.TITLE)) +
                        c.getString(c.getColumnIndex(ProviderContract.AUTHOR)) +
                        c.getString(c.getColumnIndex(ProviderContract.YEAR)) +
                        c.getString(c.getColumnIndex(ProviderContract.PAGES)) +
                        c.getString(c.getColumnIndex(ProviderContract.ISBN));

                //only pick the title from the cursor to create the listview
                String row =
                        c.getString(c.getColumnIndex(ProviderContract.TITLE));
                str += row;//make str = itself plus the value of row
                bookArrayList.add(str);//add the record to the array
                str = "";//zero out for next iteration
            } while (c.moveToNext());
        }
        //Set list view to show results of all books and set on clickliester
        //Toast.makeText(getContext(), result, Toast.LENGTH_LONG).show();//toast of all records
        ArrayAdapter<String> myAuthorAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, bookArrayList);
        listView.setAdapter(myAuthorAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String title = (String) listView.getItemAtPosition(position);
                //Toast.makeText(getContext(), title, Toast.LENGTH_SHORT).show();//toast of book title clicked
                //call method to get book by title with try/catch error to be displayed in titleET
                listener.onBookSelected(title);
            }
        });
        return bookArrayList;//not really needed since we moved all the actions into the method
    }

    //Obtain all books by year very similar to author
    public ArrayList<String> showBooksByYear (String year) {
        String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
        Uri books = Uri.parse(URL);
        Cursor c = getActivity().getContentResolver().query(
                books,//uir
                new String[] {ProviderContract.ID, ProviderContract.TITLE, ProviderContract.AUTHOR,
                        ProviderContract.YEAR, ProviderContract.PAGES, ProviderContract.ISBN},
                ProviderContract.YEAR + "=?",

                new String[] {year},
                "title");
        String result = "Results:";

        ArrayList<String> bookArrayList = new ArrayList<>();
        String str = "";
        if (!c.moveToFirst()) {
            Toast.makeText(getContext(), result + "No content!",
                    Toast.LENGTH_LONG).show();
        } else {
            do {
                result = result + "\n" +
                        c.getString(c.getColumnIndex(ProviderContract.TITLE)) +
                        c.getString(c.getColumnIndex(ProviderContract.AUTHOR)) +
                        c.getString(c.getColumnIndex(ProviderContract.YEAR)) +
                        c.getString(c.getColumnIndex(ProviderContract.PAGES)) +
                        c.getString(c.getColumnIndex(ProviderContract.ISBN));
                String row =
                        c.getString(c.getColumnIndex(ProviderContract.TITLE));
                str += row;
                bookArrayList.add(str);
                str = "";
            } while (c.moveToNext());
        }
        //Toast.makeText(getContext(), result, Toast.LENGTH_LONG).show();//toast of all records
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, bookArrayList);
        listView.setAdapter(myAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String title = (String) listView.getItemAtPosition(position);
                //Toast.makeText(getContext(), title, Toast.LENGTH_SHORT).show();//toast of book title clicked
                listener.onBookSelected(title);
            }
        });
        return bookArrayList;
    }

    //
    //Delete a book by searching base on title
    public int deleteBookByTitle (String title) {
        String URL = "content://com.example.jose.josefinal6providerapp.BookContentProvider/books";
        Uri books = Uri.parse(URL);
        int filesDeleted = getActivity().getContentResolver().delete(// (uri, String selection, String[] selectionArgs)
                books,//uri
                ProviderContract.TITLE + "=?",//selection is the row I want to search from to delete
                new String[] {title}//name of title I want to delete
        );
        return filesDeleted;
    }


    //create Options Menu (first create "menu" file in Resources with a main_menu layout
    //old comment when option menu code was in the Main Activity: MUST EXTEND "appCompatActivity",
    // extending "Activity" will not display menu
    //TO PUT OPTION MENU IN FRAGMENT USE CODE BELOW FOR THE onCreateOptionsMenu (it is different than in the Main
    //you also have to add a line above in onCreateView: setHasOptionsMenu(true);
    //and change all context to getContext()
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();//to prevent the options menu from duplicating when rotating device
        inflater.inflate(R.menu.main_menu, menu);
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //String nameStr = name.getText().toString();//get reference IOT check if its empty
        //(1) Create string for dialogue box to display when "View Books" is clicked from option menu
        String[] viewOptions = new String[]{"All Books", "Author", "Year", "Title"};
        switch (item.getItemId()) {
            case R.id.viewBooks:
                Dialog viewDialog = viewBookDialog();
                viewDialog.show();
                return true;

            case R.id.addBook:
                Dialog addDialog = addBookDialog();
                addDialog.show();
                return true;

            case R.id.deleteBook:
                Dialog deleteDialog = deleteBookDialog();
                deleteDialog.show();
                return true;

            case R.id.updateBook:
                Dialog updateDialog = updateBookDialog();
                updateDialog.show();
                return true;
            case R.id.clearBookScreen:
                listView.setAdapter(null);
                return true;


            //removed another case for clear screen but it does not make sense here based on construction of the app
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    // END create Options Menu



    public Dialog addBookDialog() {
        AlertDialog.Builder builderAdd =
                new AlertDialog.Builder(getContext());
        LayoutInflater inflaterAdd = getActivity().getLayoutInflater();//had to make getActviity()
        View vAdd = inflaterAdd.inflate(R.layout.add_dialogue, null);
        builderAdd.setView(vAdd);
        //builderAdd.setTitle("Enter Book Details");
        final EditText titleET = (EditText) vAdd.findViewById(R.id.bookTitle);
        final EditText authorET = (EditText) vAdd.findViewById(R.id.bookAuthor);
        final EditText yearET = (EditText) vAdd.findViewById(R.id.bookYear);
        final EditText pagesET = (EditText) vAdd.findViewById(R.id.bookPages);
        final EditText isbnET = (EditText) vAdd.findViewById(R.id.bookIsbn);
        builderAdd.setPositiveButton("Add Book",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(
                            DialogInterface dialog, int id) {
                        String title = titleET.getText().toString();
                        String author = authorET.getText().toString();
                        String year = yearET.getText().toString();
                        String pages = pagesET.getText().toString();
                        String isbn = isbnET.getText().toString();
                        //check if any fields are empty
                        if (TextUtils.isEmpty(title)|| TextUtils.isEmpty(author)||TextUtils.isEmpty(year)||
                                TextUtils.isEmpty(pages)||TextUtils.isEmpty(isbn)) {
                            Toast.makeText(getContext(), "All Fields Must Be Filled", Toast.LENGTH_LONG).show();

                        } else {
                            //
                            ContentValues values = new ContentValues();
                            values.put(ProviderContract.TITLE, title);
                            values.put(ProviderContract.AUTHOR, author);
                            values.put(ProviderContract.YEAR, year);
                            values.put(ProviderContract.PAGES, pages);
                            values.put(ProviderContract.ISBN, isbn);
                            Uri uri = getActivity().getContentResolver().insert(//had to add getActivity(). before getContentResolver
                                    ProviderContract.CONTENT_URI, values);
                            Toast.makeText(getContext(),  title +
                                    " Has Been Added!", Toast.LENGTH_SHORT).show();
                            showAllBooks();
                        }
                    }
                });
        builderAdd.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });
        AlertDialog addDialog = builderAdd.create();
        return addDialog;
    }


    public Dialog deleteBookDialog() {
        AlertDialog.Builder builderDelete =
                new AlertDialog.Builder(getContext());
        LayoutInflater inflaterDelete = getActivity().getLayoutInflater();//had to make getActviity()
        View vDelete = inflaterDelete.inflate(R.layout.delete_dialogue, null);
        builderDelete.setView(vDelete);
        //builderDelete.setTitle("Enter Book Title to Delete");
        final EditText deleteET = (EditText) vDelete.findViewById(R.id.bookDelete);
        builderDelete.setPositiveButton("Delete",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(
                            DialogInterface dialog, int id) {
                        String delete = deleteET.getText().toString();
                        //check if empty
                        if (TextUtils.isEmpty(delete)) {
                            Toast.makeText(getContext(), "You Must Enter A Title", Toast.LENGTH_LONG).show();
                        } else {
                            //
                            try{
                                int deletedFiles = deleteBookByTitle(delete);//the method on both this fragment and the provider return a count of records deleted
                                if (deletedFiles == 0){//if there were no records deleted then there was no match in the title requested
                                    Toast.makeText(getContext(), "No Book File Matched The Requested Title", Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(getContext(), delete+" Has Been Deleted", Toast.LENGTH_SHORT).show();
                                    showAllBooks();//to update the listview minus the deleted book
                                }
                            } catch (Exception e){
                                String str=e.getMessage();
                                Toast.makeText(getContext(), str, Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });

        builderDelete.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });

        AlertDialog deleteDialog = builderDelete.create();
        return deleteDialog;
    }


    public Dialog updateBookDialog() {
        AlertDialog.Builder builderUpdate =
                new AlertDialog.Builder(getContext());
        LayoutInflater inflaterUpdate = getActivity().getLayoutInflater();//had to make getActviity()
        View vUpdate = inflaterUpdate.inflate(R.layout.title_dialogue, null);//use same layout as title search
        builderUpdate.setView(vUpdate);
        //builderUpdate.setTitle("Enter Title to Update");
        final EditText updateET = (EditText) vUpdate.findViewById(R.id.bookTitle);
        builderUpdate.setPositiveButton("Update",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(
                            DialogInterface dialog, int id) {
                        String update = updateET.getText().toString();
                        //check if empty
                        if (TextUtils.isEmpty(update)) {
                            Toast.makeText(getContext(), "You Must Enter A Title", Toast.LENGTH_LONG).show();
                        } else {
                            //
                            Toast.makeText(getContext(), "Title Selected To Edit: "+ update, Toast.LENGTH_SHORT).show();
                            listener.onBookSelected(update);//call method in DetailFgt to get and display book details
                        }
                    }
                });
        builderUpdate.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(
                            DialogInterface dialog, int id) {
                        //…
                    }
                });

        AlertDialog updateDialog = builderUpdate.create();
        updateDialog.show();
        //(1) End of Dialogue Login
        return updateDialog;
    }


    public Dialog viewBookDialog() {
        String[] viewOptions = new String[]{"All Books", "Author", "Year", "Title"};
        AlertDialog.Builder alertdialogbuilder =
                new AlertDialog.Builder(getContext());
        alertdialogbuilder.setTitle("Select View Option ");
        alertdialogbuilder.setItems(viewOptions,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        switch(which) {
                            case 0: //view all books
                                showAllBooks();
                                break;

                            case 1: //author
                                //Toast.makeText(getContext(), "Author", Toast.LENGTH_LONG).show();
                                AlertDialog.Builder builderAuthor =
                                        new AlertDialog.Builder(getContext());
                                LayoutInflater inflaterAuthor = getActivity().getLayoutInflater();//had to make getActviity()
                                View vAuthor = inflaterAuthor.inflate(R.layout.author_dialogue, null);
                                builderAuthor.setView(vAuthor);
                                //builderAuthor.setTitle("Enter Author");
                                final EditText authorET = (EditText) vAuthor.findViewById(R.id.bookAuthor);
                                builderAuthor.setPositiveButton("Search",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                String author = authorET.getText().toString();
                                                //check if empty
                                                if (TextUtils.isEmpty(author)) {
                                                    Toast.makeText(getContext(), "You Must Enter A Author", Toast.LENGTH_LONG).show();
                                                } else {
                                                    //
                                                    Toast.makeText(getContext(), "Results Base On Author: "+ author, Toast.LENGTH_SHORT).show();
                                                    showBooksByAuthor(author);//call method to dsiplay books in the list view matching author search
                                                }
                                            }
                                        });
                                builderAuthor.setNegativeButton("Cancel",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                //…
                                            }
                                        });

                                AlertDialog authorDialog = builderAuthor.create();
                                authorDialog.show();
                                //(1) End of Dialogue Author
                                break;


                            case 2: //year
                                //Toast.makeText(getContext(), "Year", Toast.LENGTH_LONG).show();
                                AlertDialog.Builder builderYear =
                                        new AlertDialog.Builder(getContext());
                                LayoutInflater inflaterYear = getActivity().getLayoutInflater();//had to make getActviity()
                                View vYear = inflaterYear.inflate(R.layout.year_dialogue, null);
                                builderYear.setView(vYear);
                                builderYear.setTitle("Enter Author");
                                final EditText yearET = (EditText) vYear.findViewById(R.id.bookYear);
                                builderYear.setPositiveButton("Search",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                String year = yearET.getText().toString();
                                                //check if empty
                                                if (TextUtils.isEmpty(year)) {
                                                    Toast.makeText(getContext(), "You Must Enter A Year", Toast.LENGTH_LONG).show();
                                                } else {
                                                    //
                                                    Toast.makeText(getContext(), "Results Base On Year: "+ year, Toast.LENGTH_SHORT).show();
                                                    showBooksByYear(year);//call method to display books in list view matching year search
                                                }
                                            }
                                        });
                                builderYear.setNegativeButton("Cancel",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                //…
                                            }
                                        });
                                AlertDialog yearDialog = builderYear.create();
                                yearDialog.show();
                                //(1) End of Dialogue Year
                                break;
                            case 3: //title
                                //Toast.makeText(getContext(), "Title", Toast.LENGTH_LONG).show();
                                //(1) Dialogue to get user input for title and call method to display
                                AlertDialog.Builder builderTitle =
                                        new AlertDialog.Builder(getContext());
                                LayoutInflater inflaterTitle = getActivity().getLayoutInflater();//had to make getActviity()
                                View vTitle = inflaterTitle.inflate(R.layout.title_dialogue, null);
                                builderTitle.setView(vTitle);
                                builderTitle.setTitle("Enter Title");
                                final EditText titleET = (EditText) vTitle.findViewById(R.id.bookTitle);
                                builderTitle.setPositiveButton("Search",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                String title = titleET.getText().toString();
                                                //check if empty
                                                if (TextUtils.isEmpty(title)) {
                                                    Toast.makeText(getContext(), "You Must Enter A Title", Toast.LENGTH_LONG).show();
                                                } else {
                                                    //
                                                    Toast.makeText(getContext(), "Results Base On Title: "+ title, Toast.LENGTH_SHORT).show();
                                                    listener.onBookSelected(title);//call method in DetailFgt to get and display book details
                                                }
                                            }
                                        });
                                builderTitle.setNegativeButton("Cancel",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(
                                                    DialogInterface dialog, int id) {
                                                //…
                                            }
                                        });

                                AlertDialog titleDialog = builderTitle.create();
                                titleDialog.show();
                                //(1) End of Dialogue Login
                                break;
                        }
                    } // end of onClick()
                }); //end of setItems()
        AlertDialog howToViewDialog=alertdialogbuilder.create();
        return howToViewDialog;
    }



}
