package com.example.jose.josefinal6providerapp;

import android.net.Uri;

public class ProviderContract {
    static final String PROVIDER_NAME=
            "com.example.jose.josefinal6providerapp.BookContentProvider";
    static final String URL =
            "content://"+PROVIDER_NAME+"/books";
    static final Uri CONTENT_URI = Uri.parse(URL);
    static final String ID = "id";
    static final String TITLE = "title";
    static final String AUTHOR = "author";
    static final String YEAR = "year";
    static final String PAGES = "pages";
    static final String ISBN = "isbn";
}
