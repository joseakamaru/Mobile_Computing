package com.example.jose.josefinal6providerapp;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

/**
 * Created by Jose on 12/12/17.
 */

public class BookContentProvider extends ContentProvider{
    static final int BOOKS = 1;
    static final int BOOKS_ID = 2;
    BookDataBaseHelper dbHelper;
    static final UriMatcher uriMatcher;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(
                ProviderContract.PROVIDER_NAME, "books", BOOKS);
        uriMatcher.addURI(
                ProviderContract.PROVIDER_NAME, "books/#",
                BOOKS_ID);
    }

    @Override
    public boolean onCreate() {
        dbHelper = new BookDataBaseHelper(getContext());
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        if (database == null) return false;
        else return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String
            selection, String[] selectionArgs, String sortOrder) {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        SQLiteQueryBuilder queryBuilder =
                new SQLiteQueryBuilder();
        queryBuilder.setTables(BookDataBaseHelper.TABLE_NAME);
        switch (uriMatcher.match(uri)) {
            case BOOKS:
                break;
            case BOOKS_ID:
                queryBuilder.appendWhere(ProviderContract.ID + "=" + uri.getLastPathSegment());
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if (sortOrder == null || sortOrder == "") {
            sortOrder = ProviderContract.TITLE;
        }
        Cursor cursor = queryBuilder.query(database, projection,
                selection, selectionArgs, null, null, sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        long row = database.insert(BookDataBaseHelper.TABLE_NAME, "", values);
        if (row > 0) {
            Uri newUri = ContentUris.withAppendedId(ProviderContract.CONTENT_URI, row);
            getContext().getContentResolver().notifyChange(newUri, null);
            return newUri;
        }
        throw new SQLException("Failed to add new record into " + uri);
    }

    @Override
    public int update(Uri uri, ContentValues val,
                      String selection, String[] args) {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        int count = 0;
        switch (uriMatcher.match(uri)) {
            case BOOKS:
                count = database.update(BookDataBaseHelper.TABLE_NAME, val, selection, args);
                break;
            case BOOKS_ID:
                count = database.update(
                        BookDataBaseHelper.TABLE_NAME, val, ProviderContract.ID
                                + " = " + uri.getLastPathSegment()
                                + (!TextUtils.isEmpty(selection) ? " AND ("
                                + selection + ')' : ""), args);
                break;
            default:
                throw new IllegalArgumentException(
                        "Unsupported URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        int count = 0;
        switch (uriMatcher.match(uri)) {
            case BOOKS:
                count = database.delete(
                        BookDataBaseHelper.TABLE_NAME, selection, selectionArgs);
                break;
            case BOOKS_ID:
                String id = uri.getLastPathSegment();  //gets the id
                count = database.delete(BookDataBaseHelper.TABLE_NAME,
                        ProviderContract.ID + " = " + id
                                + (!TextUtils.isEmpty(selection) ? " AND ("
                                + selection + ')' : ""), selectionArgs);
                break;
            default:
                throw new IllegalArgumentException(
                        "Unsupported URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            // Get all friend-birthday records
            case BOOKS:
                return "vnd.android.cursor.dir/vnd.example.books";
            // Get a particular friend
            case BOOKS_ID:
                return "vnd.android.cursor.item/vnd.example.books";
            default:
                throw new IllegalArgumentException("Err URI: " + uri);
        }
    }

}

